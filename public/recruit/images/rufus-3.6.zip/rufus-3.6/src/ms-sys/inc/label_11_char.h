unsigned char label_11_char[] = {'N','O',' ','N','A','M','E',' ',' ',' ',' '};
