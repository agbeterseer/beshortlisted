o KERNEL.SYS was taken from KERNL386.SYS in FreeDOS Kernel 2042:
  http://ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/base/kernel.zip
  It was modified to have FORCELBA enabled (byte offset 0x0D set to 0x01)

o COMMAND.COM was extracted from FreeCom 0.84 pre 2:
  http://ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/base/command.zip

o The EGA files were extracted from CPI (Code Page Information) Package 3.0:
  http://ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/base/cpidos.zip

o DISPLAY.EXE was extracted from Display 0.13b:
  http://ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/base/display.zip

o KEYB.EXE was extracted from Keyb 2.01:
  http://ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/base/keyb.zip
  
o The keyboard layouts (KEYB___.SYS) were extracted from Keyb Layouts 3.1:
  http://ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/base/keyb_lay.zip

o MODE.COM was extracted from Mode 2015-11-25:
  http://ibiblio.org/pub/micro/pc-stuff/freedos/files/distributions/1.2/repos/base/mode.zip
